<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaseUtility extends Model
{
    use HasFactory;
    public function utilityInfo()
    {
        return $this->belongsTo(Utility::class, 'utility_id', 'id');
    }
}
