<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Property;
use App\Models\PropertyPaymentSetting;
use App\Models\PropertyType;
use App\Models\PropertyUnit;
use App\Models\PropertyExtraCharges;
use App\Models\PropertyLateFees;
use App\Models\PropertyUtility;
use App\Models\UnitType;
use App\Models\Utility;
use App\Models\ExtraCharge;
use App\Models\LateFees;
use App\Models\Lease;
use App\Models\LeaseType;
use App\Models\Tenant;
use App\Models\LeaseUtilityDeposite;
use App\Models\LeaseExtraCharge;
use App\Models\LeaseUtility;
use App\Models\AppSetting;
use App\Models\LeaseDocument;
use App\Models\RentCal;
use App\Models\Invoice;
use Validator;
use Auth;
use Exception;
use DB;
use Str;
use PDF;
class LeaseController extends Controller
{
     public function __construct()
    {
        $this->middleware('permission:invoice-browse',['only' => ['index']]);
        $this->middleware('permission:invoice-read', ['only' => ['show']]);
    }

    public function index($id = NULL)
    {
        if (\Auth::user()->can('lease-browse')) {
            $data = Lease::get();
            $propertyTypes = Property::orderby('id','desc')->get()->pluck('property_name', 'id');
            $partners = User::orderby('id','desc')->where('status','1')->get()->pluck('first_name', 'id');
            $tenants = Tenant::orderby('id','desc')->get()->pluck('firm_name', 'id');
            $id = $id;
            return View('lease.index',compact('propertyTypes','data','partners','tenants','id'));
        } else {
            return redirect()->back();
        }
    }

    public function leaseShow($id)
    {
        $leaseInfo = Lease::with(['property', 'tenant'])->find($id);

        if(!empty($leaseInfo)) {
    
            $unit_ids = explode(',', $leaseInfo->unit_ids);
            $tenant = Tenant::where('id',$leaseInfo->tenant_id)->first();
            $property = Property::where('id',$leaseInfo->property_id)->first();

            
            $propertyUnit = PropertyUnit::where('property_id',$leaseInfo->property_id)->groupby('unit_name_prefix')->orderby('id','ASC')->get();
            // Redirect to the PDF viewer
            $propertyUnitsInfo =  PropertyUnit::whereIn('id',$unit_ids)->get();
            $paymentSetting = PropertyPaymentSetting::where('lease_id',$id)->with('partner')->get();
            $rentCals = RentCal::where('lease_id',$id)->where('type','1')->orderby('id','ASC')->get();
            $camCals = RentCal::where('lease_id',$id)->where('type','2')->orderby('id','ASC')->get();
            $leaseDocuments = LeaseDocument::orderby('id','desc')->where('lease_id',$id)->get();
            return view('lease.leaseshow',compact('leaseInfo','rentCals','camCals','tenant','property','propertyUnit','unit_ids','id','paymentSetting','propertyUnitsInfo','leaseDocuments'));
            
            } else{
                return redirect()->back()->with('error', __('Lease not found.'));
            }

    }


    public function contractDocument()
    {
        if (\Auth::user()->can('lease-browse')) {
            $data = Lease::pluck('unique_id','id')->toArray();
            $propertyTypes = Property::get()->pluck('property_name', 'id');
            $partners = User::get()->pluck('first_name', 'id');
            return View('lease.contract-document',compact('data'));
        } else {
            return redirect()->back();
        }
    }
    public function fetchLeaseData(Request $request)
    {
        $lease = Lease::with('property','tenant')->find($request->id);

        return response()->json([
            'content' => $this->generateLeaseContent($lease,$request)
        ]);
    }

public function previewPdf(Request $request, $id)
{
    $content = $request->input('content');
    $pdf = PDF::loadHTML($content); // Use a PDF library like Dompdf or Snappy
    $pdfPath = storage_path('app/public/lease_preview.pdf');
    $pdf->save($pdfPath);

    return response()->json(['pdfUrl' => asset('storage/lease_preview.pdf')]);
}


private function generateLeaseContent($lease,$request)
{
    $appSetting = AppSetting::first();
    $total_square = $lease->total_square;
    $price_per_sqare_ft = $lease->price;
    $monthly_rent =  $total_square * $price_per_sqare_ft;
    $cam_amount =  $total_square * $lease->camp_price;
    // Generate dynamic content using the lease data
    $content = "Lease Agreement for {$lease->property_name}...";
    // Replace placeholders with actual data
    $content = str_replace([
        '{owner_name}', '{owner_address}', '{owner_phone}', '{owner_email}', '{property_name}',
        '{property_code}', '{lease_area_of_sq}', '{property_address}', '{tenant_name}', '{tenant_address}',
        '{tenant_phone}', '{tenant_email}', '{lease_start_date}', '{monthly_rent_amount}', '{lease_price_per_sq}',
        '{lease_units}', '{lease_end}', '{lease_cam}'
    ], [
        $appSetting->app_name, $appSetting->address, $appSetting->mobile_no, $appSetting->email, $lease->property->property_name,
        $lease->property->property_code, $lease->total_square, $lease->property->location, $lease->tenant->firm_name, $lease->tenant->business_address,
        $lease->tenant->phone, $lease->tenant->email, $lease->start_date, $monthly_rent, $lease->price,
        $lease->unit_ids, $lease->end_month, $cam_amount
    ], $request->content);

    return $content;
}

    
    public function leaseList(Request $request)
    {
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        $query = Lease::select('leases.*')
            ->when($startDate, function($query) use ($startDate) {
                return $query->whereDate('leases.start_date', '>=', $startDate);
            })
            ->when($endDate, function($query) use ($endDate) {
                return $query->whereDate('leases.start_date', '<=', $endDate);
            })->orderBy('leases.id','DESC')->with('property','tenant');
       
        if(!empty($request->property_id))
        {
            $query->where('leases.property_id', $request->property_id);
        }
        if(!empty($request->tenant_id))
        {
            $query->where('leases.tenant_id', $request->tenant_id);
        }
        if($request->status!='')
        {
            $query->where('leases.status', $request->status);
        }
        return datatables($query)
            ->editColumn('property_id', function ($query)
            {
                
                return $query->property->property_name;
            })
            ->editColumn('tenant_id', function ($query)
            {
                
                return $query->tenant->firm_name;
            })
            ->editColumn('start_date', function ($query)
            {
                
                return date('M d ,Y',strtotime($query->start_date));
            })
           
            ->editColumn('status', function ($query)
            {
                if ($query->status == 'Approved')
                {
                    $status = 'Approved';
                    $class='bg-label-success';
                }
                elseif ($query->status == 'Processing')
                {
                    $status = 'Processing';
                    $class='bg-label-info';
                }
                else
                {
                    $status = 'Pending';
                    $class='bg-label-primary';
                }

                return '<span class="badge '.$class.' text-capitalize ">' . $status . '</span>';
            })

            ->addColumn('action', function ($query)
            {

               
                $edit =' <a class="btn btn-sm btn-primary" href="'.route('leases.edit', $query->id) .'" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="ti ti-pencil"></i></a>';
                
                $delete = '<a href="'.route('leases-destroy', $query->id) .'" 
                                 class="btn btn-sm btn-danger"
                                onClick="return confirm(\'Are you sure you want to delete this?\');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
                                <i class="ti ti-trash"></i>
                            </a>';
                $view =' <a class="btn btn-sm btn-primary" href="'.route('generate-pdf', $query->id) .'" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="ti ti-eye"></i></a>';



                return '<div class="btn-group btn-group-xs">'.$edit.$view.$delete.'</div>';
            })
        ->escapeColumns(['action'])
        ->addIndexColumn()
        ->make(true);
    }

     public function create(Request $request)
    {

        if (\Auth::user()->can('lease-add')) {

            $property_id = (!empty($request->property_id)) ? $request->property_id: NULL;
            if(!empty($property_id)){
                $properties = Property::where('id',$property_id)->orderby('id','desc')->pluck('property_name','id')->toArray();
                $tenants = Tenant::where('property_id',$property_id)->orderby('id','desc')->pluck('firm_name','id')->toArray();
             } else{
                $properties = Property::orderby('id','desc')->pluck('property_name','id')->toArray();
                $tenants = Tenant::orderby('id','desc')->pluck('firm_name','id')->toArray();
             }
           
           
            $leaseTypes = LeaseType::orderby('id','desc')->get()->pluck('display_name', 'id');
            $propertyTypes = PropertyType::orderby('id','desc')->get()->pluck('display_name', 'id');
            $partners = User::orderby('id','desc')->where('status','1')->where('role_id','2')->get()->pluck('first_name', 'id');
            $unitTypes = UnitType::orderby('id','desc')->get()->pluck('display_name', 'id');
            $utilities = Utility::orderby('id','desc')->pluck('display_name', 'id')->toArray();
            $extraCharges = ExtraCharge::orderby('id','desc')->get()->pluck('display_name', 'id');
            $lateFees = LateFees::orderby('id','desc')->get()->pluck('display_name', 'id');

            return view('lease.create',compact('propertyTypes','property_id','partners','unitTypes','utilities','extraCharges','lateFees','leaseTypes','properties','tenants'));
        } else {
            return redirect()->back();
        }
    }
    public function store(Request $request)
    {

      
       if(!empty($request->id))
        {
            $validator = \Validator::make(
                $request->all(), [
                    'tenant_id' => 'required|exists:tenants,id',
                    'property_id' => 'required|exists:properties,id',
                    'unit_ids.*' => 'required','unit_ids' => 'required|array|min:1',
                    'unit_ids.*' => 'integer|distinct',
                    'total_square' => 'required',
                    'price' => 'required',
                ]
            );
            if ($validator->fails()) {
                return response()->json([
                    'errors' => $validator->errors()
                ], 422);
            }

            $checkLeaseAlready = Lease::where('tenant_id', $request->tenant_id)
                ->where('property_id', $request->property_id)
                ->where('id','!=', $request->id)
                ->first();

            if ($checkLeaseAlready) {
                return response()->json([
                    'error' => 'A lease already exists for this tenant on the specified property.',
                ], 422);
            }

        } else{
            $validator = \Validator::make(
                $request->all(), [
                    'tenant_id' => 'required|exists:tenants,id',
                    'property_id' => 'required|exists:properties,id',
                    'unit_ids' => 'required|array|min:1',
                    'unit_ids.*' => 'integer|distinct',
                    'total_square' => 'required',
                    'price' => 'required',
                ]
            );
            if ($validator->fails()) {
                return response()->json([
                    'errors' => $validator->errors()
                ], 422);
            }

            $checkLeaseAlready = Lease::where('tenant_id', $request->tenant_id)
                ->where('property_id', $request->property_id)
                ->first();

            if ($checkLeaseAlready) {
                return response()->json([
                    'error' => 'A lease already exists for this tenant on the specified property.',
                ], 422);
            }

        }

        
        DB::beginTransaction();
        try{

               
                if(!empty($request->id))
                {
                    $lease = Lease::find($request->id);
                    

                } else{
                    $lease = new Lease;
                }
                $appSetting = AppSetting::first();
                $lease_prefix = (!empty($appSetting->lease_prefix)) ? $appSetting->lease_prefix :'LS';
                $unit_ids  = (!empty($request->unit_ids)) ? implode(',',$request->unit_ids) :'';
                
                $lease->user_id = auth()->user()->id;
                $lease->unique_id       = $lease_prefix.'-'.rand(0,99999);
                $lease->property_id       = $request->property_id;
                $lease->tenant_id       = $request->tenant_id;
                $lease->unit_ids       = $unit_ids;
                $lease->start_date       = (!empty($request->start_date)) ? $request->start_date :date('Y-m-d');
                $lease->due_on       = $request->due_on;
                $lease->total_square       = $request->total_square;
                $lease->price       = $request->price;
                $lease->fixed_price       = $request->fixed_price;
                $lease->square_foot       = $request->square_foot;
                $lease->cam_square_foot       = $request->cam_square_foot;
                $lease->camp_price       = $request->camp_price;
                $lease->camp_fixed_price       = $request->camp_fixed_price;
                $lease->total_rent       = $request->final_total;
                $lease->total_cam       = $request->camp_total;
                $lease->month       = $request->month;
                $lease->end_month       = $request->end_month;
                $lease->inc_percenatge       = $request->inc_percenatge;
                $lease->cam_month       = $request->cam_month;
                $lease->cam_inc_percenatge       = $request->cam_inc_percenatge;
                $lease->load_taken       = $request->load_taken;
                $lease->lease_invoice_type       = $request->lease_invoice_type;
                $lease->status       = 'Approved';
                $lease->created_by       = auth()->user()->id;
                $lease->save();


                if($lease) {

                    $messages = 'Lease successfully created';

                    if(!empty($request->id))
                    {
                        PropertyPaymentSetting::where('lease_id',$request->id)->delete();
                        LeaseUtilityDeposite::where('lease_id',$request->id)->delete();
                        LeaseExtraCharge::where('lease_id',$request->id)->delete();
                        LeaseUtility::where('lease_id',$request->id)->delete();
                        RentCal::where('lease_id',$request->id)->delete();

                        $leaseUnits = explode(',',$lease->unit_ids);
                        if(is_array(@$leaseUnits) && count(@$leaseUnits) >0 ){
                            foreach ($leaseUnits as $key => $unit) {
                                $updateOldLeaseData = PropertyUnit::where('id',$unit)->first();
                                $updateOldLeaseData->is_rented = 0;
                                $updateOldLeaseData->total_square = NULL;
                                $updateOldLeaseData->price = NULL;
                                $updateOldLeaseData->cam_square = NULL;
                                $updateOldLeaseData->cam_price = NULL;
                                $updateOldLeaseData->total_rent = NULL;
                                $updateOldLeaseData->total_cam = NULL;
                                $updateOldLeaseData->save();
                            }

                        }
        
                        $messages = 'Lease successfully updated';
                    }

                    /*--------Commission---------------------*/
                    if(is_array(@$request->partners) && count(@$request->partners) >0 ){
                        for ($i = 0;$i <= count($request->partners);$i++) {
                            if (!empty($request->partners[$i])) {
                                $default_partner = isset($request->default_partner[$i]) ?  @$request->default_partner[$i] :0;
                                $commission_value = isset($request->commission_value[$i]) ?  @$request->commission_value[$i] :100;
                                $commission_type = isset($request->commission_type[$i]) ?  @$request->commission_type[$i] :2;

                                $paymentSetting = new PropertyPaymentSetting;
                                $paymentSetting->lease_id = $lease->id;
                                $paymentSetting->tenant_id = $lease->tenant_id;
                                $paymentSetting->user_id = @$request->partners[$i];
                                $paymentSetting->property_id = $lease->id;
                                $paymentSetting->commission_value = $commission_value;
                                $paymentSetting->commission_type = $commission_type;
                                $paymentSetting->is_gst = @$request->is_gst[$i];
                                $paymentSetting->default_partner = $default_partner;
                                $paymentSetting->save();

                            }
                        }
                    }
                    /*-----------Rent Cal*/
                    if(is_array(@$request->from_month) && count(@$request->from_month) >0 ){
                        for ($i = 0;$i <= count(@$request->from_month);$i++) {
                            if (!empty(@$request->from_month[$i])) {
                                $rentCal = new RentCal;
                                $rentCal->lease_id  = $lease->id;
                                $rentCal->from_month  = @$request->from_month[$i] ;
                                $rentCal->to_month = @$request->to_month[$i];
                                $rentCal->inc_percentage = @$request->set_price[$i];
                                $rentCal->inc_amount = @$request->inc_rent_amount[$i];
                                $rentCal->type = '1';
                                $rentCal->save();
                                

                            }
                        }
                    }
                     /*-----------Cam Cal*/
                    if(is_array(@$request->cam_from_month) && count(@$request->cam_from_month) >0 ){
                        for ($i = 0;$i <= count(@$request->cam_from_month);$i++) {
                            if (!empty(@$request->cam_from_month[$i])) {
                                $rentCal = new RentCal;
                                $rentCal->lease_id  = $lease->id;
                                $rentCal->from_month  = @$request->cam_from_month[$i] ;
                                $rentCal->to_month = @$request->cam_to_month[$i];
                                $rentCal->inc_percentage = @$request->cam_set_price[$i];
                                 $rentCal->inc_amount = @$request->inc_cam_amount[$i];
                                $rentCal->type = '2';
                                $rentCal->save();
                                

                            }
                        }
                    }

                    /*--------Unit---------------------*/
                    if(is_array(@$request->deposit_amount) && count(@$request->deposit_amount) >0 ){
                        for ($i = 0;$i <= count(@$request->deposit_amount);$i++) {
                            if (!empty(@$request->deposit_amount[$i])) {
                                $leaseDeposit = new LeaseUtilityDeposite;
                                $leaseDeposit->lease_id  = $lease->id;
                                $leaseDeposit->property_id  = $request->property_id ;
                                $leaseDeposit->utility = @$request->utility[$i];
                                $leaseDeposit->deposit_amount = @$request->deposit_amount[$i];
                                $leaseDeposit->save();
                                

                            }
                        }
                    }
                   
                   
                    /*--------Extra Charge---------------------*/
                    if(is_array(@$request->extra_charge_value) && count(@$request->extra_charge_value) >0 ){
                        for ($i = 0;$i <= count(@$request->extra_charge_value);$i++) {
                            if (!empty(@$request->extra_charge_value[$i])) {
                                $extraCharge = new LeaseExtraCharge;
                                $extraCharge->lease_id = $lease->id;
                                $extraCharge->property_id = $request->property_id;
                                $extraCharge->tenant_id = $request->tenant_id;
                                $extraCharge->extra_charge_id = @$request->extra_charge_id[$i];
                                $extraCharge->extra_charge_value = @$request->extra_charge_value[$i];
                                $extraCharge->extra_charge_type = @$request->extra_charge_type[$i];
                                $extraCharge->frequency = @$request->frequency[$i];
                                $extraCharge->save();

                            }
                        }
                    }
                   

                    /*--------Utilities---------------------*/
                    if(is_array(@$request->variable_cost) && count(@$request->variable_cost) >0 ){
                        for ($i = 0;$i <= count(@$request->variable_cost);$i++) {
                            if (!empty(@$request->variable_cost[$i])) {
                                $leaseutility = new LeaseUtility;
                                $leaseutility->lease_id = $lease->id;
                                $leaseutility->property_id = $request->property_id;
                                $leaseutility->tenant_id = $request->tenant_id;
                                $leaseutility->utility_id = @$request->utility_id[$i];
                                $leaseutility->variable_cost = @$request->variable_cost[$i];
                                $leaseutility->fixed_cost = @$request->fixed_cost[$i];
                                $leaseutility->save();

                            }
                        }
                    }

                   
                    if(!empty(@$request->doc_ids)){
                        $doc_ids = explode(',',$request->doc_ids);
                        $deleleOldDoc = LeaseDocument::whereIn('id',$doc_ids)->delete();
                    }
                    if ($request->hasFile('documents')) {
                        $destinationPath    = 'assets/uploads/';

                        foreach ($request->file('documents') as $file) {
                            // Generate a unique file name to prevent overwriting
                            $fileName = 'doc-'.time() . '_' . $file->getClientOriginalExtension();
                            
                            // Store the file in 'public/assets/uploads' directory
                            $path = $file->storeAs($destinationPath, $fileName, 'customer_uploads');

                            $saveFile = $destinationPath.$fileName;
                                
                            $leaseDocument = new LeaseDocument;
                            $leaseDocument->lease_id = $lease->id;
                            $leaseDocument->file_name = $fileName;
                            $leaseDocument->document = $saveFile;
                            $leaseDocument->save();
                           
                        }
                    }
                   

                    if(is_array(@$request->unitn) && count(@$request->unitn) >0 ){
                        foreach ($request->unitn as $key => $unit) {
                            $uData = PropertyUnit::where('unit_name',$unit)->where('property_id',$request->property_id)->first();
                            $updateUnitData = PropertyUnit::find($uData->id);
                            $updateUnitData->is_rented = 1;
                            $updateUnitData->total_square = @$request->square_feet[$key];
                            $updateUnitData->price = @$request->rate[$key];
                            $updateUnitData->cam_square = @$request->cam_square_feet[$key];
                            $updateUnitData->cam_price = @$request->cam_rate[$key];
                            $updateUnitData->total_rent = @$request->renttotal[$key];
                            $updateUnitData->total_cam = @$request->camtotal[$key];
                            $updateUnitData->save();

                        }

                    }
                    
                 

               
                 DB::commit();
                return response()->json([
                    'message' => $messages
                ], 200);
            } else {
                return response()->json([
                    'errors' => 'Something went wrong!'
                ], 500);
            }
        
        } catch (Exception $exception) {
            \Log::info($exception->getMessage());
            return response()->json([
                'errors' => $exception->getMessage()
            ], 500);
        }
    }

    public function edit($id)
    {
        if (\Auth::user()->can('lease-edit')) {
            $lease = Lease::findOrFail($id);
            $checkLeaseApproved = Lease::where('id',$id)->where('status','Approved')->first();
            /*if(!empty($checkLeaseApproved)){
               return redirect()->route('leases.index')->with('error', __("You can't  edit this lease."));
            }*/
            $unit_ids = explode(',', $lease->unit_ids);

            $propertyUnit = PropertyUnit::where('property_id',$lease->property_id)->groupby('unit_name_prefix')->orderby('id','ASC')->get();
            $rented_units = PropertyUnit::select('id')->where('property_id',$lease->property_id)->where('is_rented','1')->orderby('id','ASC')->get()->toArray();
            $properties = Property::orderby('id','desc')->pluck('property_name','id')->toArray();
            $tenants = Tenant::orderby('id','desc')->pluck('firm_name','id')->toArray();
            $leaseDeposits = LeaseUtilityDeposite::orderby('id','desc')->where('lease_id',$id)->get();
            $leaseExtraCharges = LeaseExtraCharge::orderby('id','desc')->where('lease_id',$id)->get();;
            $leaseUtilities = LeaseUtility::orderby('id','desc')->where('lease_id',$id)->get();;
            $partners = User::orderby('id','desc')->where('status','1')->where('role_id','2')->get()->pluck('first_name', 'id');
            $utilities = Utility::orderby('id','desc')->pluck('display_name', 'id')->toArray();
            $extraCharges = ExtraCharge::orderby('id','desc')->get()->pluck('display_name', 'id');
            $paymentSetting = PropertyPaymentSetting::orderby('id','desc')->where('lease_id',$id)->with('partner')->get();
            $leaseDocuments = LeaseDocument::orderby('id','desc')->where('lease_id',$id)->get();
            $rentCals = RentCal::orderby('id','desc')->where('lease_id',$id)->where('type','1')->orderby('id','ASC')->get();
            $camCals = RentCal::orderby('id','desc')->where('lease_id',$id)->where('type','2')->orderby('id','ASC')->get();
            $partners = User::orderby('id','desc')->where('role_id','2')->get()->pluck('first_name', 'id');
            return View('lease.edit',compact('lease','properties','tenants','leaseDeposits','leaseExtraCharges','leaseUtilities','utilities','extraCharges','propertyUnit','unit_ids','rented_units','paymentSetting','partners','leaseDocuments','rentCals','camCals'));
        } else {
            return redirect()->back();
        }
    }
     public function destroy($id)
    {
        if (\Auth::user()->can('lease-delete')) {

            $leaseExist = Invoice::where('lease_id',$id)->count();
            if($leaseExist > 0){
                return redirect()->back()->with('error', __("You can't  delete this lease."));
            }

            $lease = Lease::find($id);
            if ($lease) {
                $leaseUnits = explode(',',$lease->unit_ids);
                if(is_array(@$leaseUnits) && count(@$leaseUnits) >0 ){
                    foreach ($leaseUnits as $key => $unit) {
                        $updateOldLeaseData = PropertyUnit::where('id',$unit)->first();
                        $updateOldLeaseData->is_rented = 0;
                        $updateOldLeaseData->total_square = NULL;
                        $updateOldLeaseData->price = NULL;
                        $updateOldLeaseData->cam_price = NULL;
                        $updateOldLeaseData->cam_square = NULL;
                        $updateOldLeaseData->total_rent = NULL;
                        $updateOldLeaseData->total_cam = NULL;
                        $updateOldLeaseData->save();
                    }

                }
                $lease->delete();
                PropertyPaymentSetting::where('lease_id',$id)->delete();
                LeaseUtilityDeposite::where('lease_id',$id)->delete();
                LeaseExtraCharge::where('lease_id',$id)->delete();
                LeaseUtility::where('lease_id',$id)->delete();
                RentCal::where('lease_id',$id)->delete();
                return redirect()->route('leases.index')->with('success', __('Lease successfully deleted .'));
            } else {
                return redirect()->back()->with('error', __('Lease not found.'));
            }
        } else {
            return redirect()->back();
        }
        
    }
     public function getUnits(Request $request)
    {
       
        $propertyUnit = PropertyUnit::where('property_id',$request->property_id)->groupby('unit_name_prefix')->orderby('id','ASC')->get();
       
        $output = '';
        $selected = '';
        $output .='<div class=""> <label for="unit_ids" class="form-label">Property Units</label> <span class="requiredLabel">*</span>';
              foreach($propertyUnit as $floor) {
                $allUnits = \App\Models\PropertyUnit::where('property_id',$floor->property_id)->where('unit_name_prefix',$floor->unit_name_prefix)->orderby('id','ASC')->get(); 

                $output .='<div class="floor" data-floor="floor-'.$floor->id .'"><h6 style="grid-column: span 9;"><span class="badge bg-label-primary">'.$floor->unit_floor .' ('.$floor->unit_name_prefix .')</span>&nbsp;&nbsp;&nbsp;<button type="button" class="select-all btn btn-sm btn-primary" data-floor="floor-'.$floor->id .'">Select All</button></h6> ';
                foreach($allUnits as $unit) {
                    $is_rented =  ($unit->is_rented =='1') ? 'red' :'' ;
                    $is_rented_color =  ($unit->is_rented =='1') ? '#fff !important' :'#767283' ;
                    $class= (!empty($is_rented)) ? 'btn' :'btn-outline-primary';
                    $output .= '<div class="unit '.$class.'" style="background:'.$is_rented.';color:'.$is_rented_color.'">';
                    $output .= '<input type="checkbox" name="unit_ids[]" value="'.$unit->id.'" data-name="'.$unit->unit_name.'"   data-totalsquare="'.$unit->total_square.'" data-price="'.$unit->price.'"  data-camprice="'.$unit->cam_price.'" data-campsquare="'.$unit->cam_square.'"   data-renttotal="'.$unit->total_rent.'" data-camtotal="'.$unit->total_cam.'"  class="unit-checkbox" id="unit-'.$unit->id.'" ';
                    $output .= ($unit->is_rented == "1") ? 'disabled' : '';
                    $output .= ' onclick="unitCheckboxClicked(this)">';  // Add the onclick attribute
                    $output .= '<label for="unit-'.$unit->id.'">'.$unit->unit_name.'</label>';
                    $output .= '</div>';

                    
                    }
                    $output .= '</div>';
                }
           $output .='</div>';

        return $output;
        
        
    }
    public function getUnitsold(Request $request)
    {
       
        $propertyUnits = PropertyUnit::where('property_id',$request->property_id)->get();
       
        $output = '';
        $selected = '';
        $output .=' <div class="select2-primary"><select class="form-control select2 form-select" aria-label="Floating label select example" name="unit_ids[]"  id="unit_ids" multiple="multiple" data-allow-clear="true">';
              foreach($propertyUnits as $unit) {
                $output .='<option  value="'.$unit->id.'"  >
                    '.ucfirst($unit->unit_name) .'
                </option>';
                }
           $output .=' </select></div>';

        return $output;
        
        
    }
   

    
}
