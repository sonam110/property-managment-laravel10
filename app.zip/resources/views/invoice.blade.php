<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<title>A simple, clean, and responsive HTML invoice template</title>

		<!-- Favicon -->
		<link rel="icon" href="./images/favicon.png" type="image/x-icon" />

		<!-- Invoice styling -->
		<style>
			body {
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				text-align: center;
				color: #777;
			}

			body h1 {
				font-weight: 300;
				margin-bottom: 0px;
				padding-bottom: 0px;
				color: #000;
			}

			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style: italic;
				color: #555;
			}

			body a {
				color: #06f;
			}

			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
				border-collapse: collapse;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: right;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}
		</style>
	</head>
	<body>
		<div class="row invoice-preview">
            <!-- Invoice -->
            <div class="col-xl-9 col-md-9 col-12 mb-md-0 mb-4">
              <div class="card invoice-preview-card">
                <div class="card-body">
                  <div
                    class="d-flex justify-content-between flex-xl-row flex-md-column flex-sm-row flex-column m-sm-3 m-0">
                    <div class="mb-xl-0 mb-4">
                      <a class="header-brand" href="http://localhost:8000" class="app-brand-link">
                        <img src="http://localhost:8000/assets/uploads/property-management-1724824115.jpg" class="" alt="SIGNATURE INFRATECH">
                      </a> 
                      <p class="mb-2">Signature Group Corporate, 36-A, Vidhya Nagar Phase 2, Hoshangabaad Road, Bhopal (M.P.) 462026</p>
                      <p class="mb-2">MADHYA PRADESH,INDIA</p>
                      <p class="mb-0">(+91) 8959910931</p>
                    </div>
                    <div>
                      <h5 class="fw-medium mb-2">INVOICE #Aug/2024/907</h5>
                      <div class="mb-2 pt-1">
                        <span>Date Issues:</span>
                        <span class="fw-medium">Aug 30,2024</span>
                      </div>

                      <div class="pt-1">
                        <span>Date Due:</span>
                        <span class="fw-medium">Sep 09,2024</span>
                      </div>
                    </div>
                  </div>
                </div>
                <hr class="my-0" />
                <div class="card-body">
                  <div class="row p-sm-3 p-0">
                    <div class="col-xl-6 col-md-12 col-sm-5 col-12 mb-xl-0 mb-md-4 mb-sm-0 mb-4">
                      <h6 class="mb-3">Invoice To:</h6>
                      <p class="mb-1">NRT</p>
                      <p class="mb-1">NRT</p>
                      <p class="mb-1">Arera Colony</p>
                      <p class="mb-1">9713753131</p>
                      <p class="mb-0">ashok@nrt.co.in</p>
                    </div>
                    <div class="col-xl-6 col-md-12 col-sm-7 col-12">
                      <h6 class="mb-4">Bill To:</h6>
                      <table>
                        <tbody>
                          <tr>
                            <td class="pe-4">Total Due:</td>
                            <td class="fw-medium"><i class="ti ti-currency-rupee ti-xs me-2"></i> 261200.00</td>
                          </tr>
                          <tr>
                            <td class="pe-4">GST NO:</td>
                            <td></td>
                          </tr>
                          <tr>
                            <td class="pe-4">PAN NO:</td>
                            <td></td>
                          </tr>
                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div class="table-responsive border-top">
                  <table class="table m-0 datatables-basic table dataTable">
                    <thead>
                      <tr>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Rate</th>
                        <th>PER</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                                                                                        <tr class="rent">
                                                <td class="text-nowrap"><b>RENT INCOME -August 1, 2024-August 31, 2024</b></td>
                                                <td class="text-nowrap">2000</td>
                        <td class="text-nowrap"> 100.00 </td>
                        <td>Month</td>
                      
                        <td> 200000.00</td>
                      </tr>
                                                                  <tr class="rent">
                                                 <td class="text-nowrap">OUTPUT-CGST ON RENT</td>
                                                <td class="text-nowrap"></td>
                        <td class="text-nowrap"> 9.00 %</td>
                        <td></td>
                      
                        <td> 18000.00</td>
                      </tr>
                                                                  <tr class="rent">
                                                 <td class="text-nowrap">OUTPUT-SGST ON RENT</td>
                                                <td class="text-nowrap"></td>
                        <td class="text-nowrap"> 9.00 %</td>
                        <td></td>
                      
                        <td> 18000.00</td>
                      </tr>
                                             <tr class="rent">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><b>Total</b></td>
                        <td><b><i class="ti ti-currency-rupee ti-xs me-2"></i>236000</b></td>
                        
                     </tr>
                                                                  <tr class="cam">
                                                <td class="text-nowrap"><b>CAM CHARGES -August 1, 2024-August 31, 2024</b></td>
                                                <td class="text-nowrap">2000</td>
                        <td class="text-nowrap"> 10.00 </td>
                        <td>Month</td>
                      
                        <td> 20000.00</td>
                      </tr>
                                                                  <tr class="cam">
                                                 <td class="text-nowrap">OUTPUT-CGST ON CAM</td>
                                                <td class="text-nowrap"></td>
                        <td class="text-nowrap"> 9.00 %</td>
                        <td></td>
                      
                        <td> 1800.00</td>
                      </tr>
                                                                  <tr class="cam">
                                                 <td class="text-nowrap">OUTPUT-SGST ON CAM</td>
                                                <td class="text-nowrap"></td>
                        <td class="text-nowrap"> 9.00 %</td>
                        <td></td>
                      
                        <td> 1800.00</td>
                      </tr>
                                            <tr class="cam">>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><b>Total</b></td>
                        <td><b><i class="ti ti-currency-rupee ti-xs me-2"></i>23600</b></td>
                        
                     </tr>
                    </tbody>
                                      <tfoot>
                      <tr>
                       
                        <td colspan="1"><b> Grand Total</b></td>
                        <td colspan="4"><b><i class="ti ti-currency-rupee ti-xs me-2"></i>259600</b></td>
                        
                    </tr>
                     <tr>
                       
                        <td colspan="1"><b>Amount Chargeable (in words):</b></td>
                        <td colspan="5"><b>two hundred fifty-nine thousand six hundred</b></td>
                        
                    </tr>
                    </tfoot>
                  </table>
                  <br>
                  <table class="dt-complex-header table table-bordered dataTable">
                    <thead>
                      <tr>
                        <th rowspan="2">HSN/SAC</th>
                        <th rowspan="1">Taxable</th>
                        <th colspan="2">Central Tax</th>
                        <th colspan="2">State Tax</th>
                        <th rowspan="1">Total</th>
                      </tr>
                      <tr>

                        <th>Value</th>
                        <th>Rate</th>
                        <th>Amount</th>
                        <th>Rate</th>
                        <th>Amount</th>
                        <th>Tax Amount</th>
                      
                      </tr>
                    </thead>
                    <tbody>
                      <tr class="rent">
                       <td>997212</td>
                        <td>200000.00</td>
                        <td>9.00 %</td>
                         <td>18000.00</td>
                        <td>9.00 %</td>
                        <td>18000.00</td>
                        <td>36000</td>
                     <tr class="cam">
                      <tr>
                       <td>CAM</td>
                        <td>20000.00</td>
                        <td>9.00 %</td>
                         <td>1800.00</td>
                        <td>9.00 %</td>
                        <td>1800.00</td>
                        <td>1800</td>
                     <tr>
                    </tbody>
                                        <tfoot>
                      <tr>
                        <td><b>Total</b></td>
                        <td>220000</td>
                        <td></td>
                        <td><b>19800</b></td>
                        <td></td>
                        <td><b>19800</b></td>
                        <td><b>39600</b></td>
                        
                    </tr>
                     <tr>
                       
                        <td colspan="2"><b>Tax Amount ( (in words):</b></td>
                        <td colspan="4"><b>thirty-nine thousand six hundred</b></td>
                        
                    </tr>
                    </tfoot>
                  
                  </table>

                   <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Service Description</th>
                        <th>Quantity</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                                                                  <tr>
                       <td>Electricity</td>
                       <td>1</td>
                      <td>1000.00</td>
                     </tr>
                                                                 <tr>
                       <td>Water</td>
                       <td>1</td>
                      <td>600.00</td>
                     </tr>
                                         </tbody>
                                        <tfoot>
                       <tr>
                        <td></td>
                        <td><b>Total</b></td>
                        <td><b><i class="ti ti-currency-rupee ti-xs me-2"></i>1600</b></td>
                        
                    </tr>
                     <tr>
                       
                        <td colspan="2"><b>Utility Chargeable ( (in words):</b></td>
                        <td colspan="4"><b>one thousand six hundred</b></td>
                        
                    </tr>
                    </tfoot>
                  
                  </table>

                </div>

                <div class="card-body mx-3">
                  <div class="row">
                    <div class="col-12">
                      <span class="fw-medium">Note:</span>
                      <span
                        >We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.. Thank You!</span
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /Invoice -->
        </tr>
           
	</body>
</html>